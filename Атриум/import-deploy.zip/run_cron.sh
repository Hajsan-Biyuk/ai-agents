#!/bin/bash
# Cron-обёртка импорта Атриум (вставить в панель Beget: расписание */30 * * * *)
cd /home/s/sheer26/atriumceramic.sheer26.ru/import
/usr/bin/python3 run_import.py >> reports/cron.log 2>&1
