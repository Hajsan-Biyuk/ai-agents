# Атриум — сервер импорта товаров

Конвейер: `inbox/{поставщик}/` → нормализация → dry-run → импорт на сайт → `processed/` + отчёт.

## Расположение

| Где | Путь |
|-----|------|
| Сервер (Beget) | `/home/s/sheer26/atriumceramic.sheer26.ru/import/` (вне public_html) |
| Endpoint сайта | `public_html/local/tools/import/receive.php` (токен) |
| Импортёр Bitrix | `public_html/local/php_interface/atrium_import/AtriumImporter.php` |
| Локальная копия | `Атриум/import/` (этот каталог) |

## Как загрузить товары (менеджер)

1. Положить Excel-файлы поставщика в `import/inbox/{artkera|rgw|santehcentr}/` (SFTP или файловый менеджер Beget).
2. Дождаться cron (или попросить запуск вручную).
3. Отчёт — в `import/reports/`, обработанные файлы — в `processed/`, проблемные — в `quarantine/` (с причиной в `REASON.txt`).

## Запуск вручную (SSH)

```bash
cd ~/atriumceramic.sheer26.ru/import

python3 run_import.py --dry-run-only              # только проверка, без записи
python3 run_import.py --supplier artkera --confirm # импорт с ручным подтверждением
python3 run_import.py                              # cron-режим: импорт только при auto_confirm=true
```

## Cron (панель Beget)

Задание (каждые 30 минут):

```
/bin/bash /home/s/sheer26/atriumceramic.sheer26.ru/import/run_cron.sh
```

Лог: `import/reports/cron.log`.

## Защита от ошибок (config.yaml, per-supplier)

| Параметр | Смысл |
|----------|-------|
| `auto_confirm: false` | cron делает только dry-run; импорт — вручную с `--confirm`. После обкатки можно включить `true` |
| `max_convert_errors` | больше ошибок конвертации → файл в карантин |
| `max_create_auto` | dry-run создаёт больше N товаров → карантин (защита от кривого файла) |
| `with_photos` | скачивать фото новым товарам |

Ошибки dry-run (любые) → карантин, импорт не выполняется.

## Подключение нового поставщика

1. `suppliers/_шаблон_/` → `suppliers/{key}/` (`profile.yaml` — синонимы колонок, `categories.yaml` — маппинг категорий).
2. `mkdir inbox/{key}`.
3. Блок в `config.yaml` → `suppliers.{key}`.
4. Тест: `python3 run_import.py --supplier {key} --dry-run-only`.

## Правила

- Импорт **только upsert** по артикулу (`CML2_ARTICLE`): создаёт и обновляет, никогда не удаляет.
- `config.yaml` содержит токен — **не коммитить** (в `.gitignore`).
- Python-зависимости на сервере: `pip3 install --user pandas openpyxl xlrd` (pyyaml системный).
