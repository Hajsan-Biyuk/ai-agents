#!/usr/bin/env python3
"""
Оркестратор импорта Атриум (запускается по cron на сервере).

Цикл: inbox/{supplier}/ → convert → валидация → dry-run → импорт → processed/ + отчёт.
Файлы с ошибками → quarantine/ и импорт НЕ выполняется.

Запуск:
    python3 run_import.py                  # все поставщики; импорт только при auto_confirm=true
    python3 run_import.py --supplier artkera
    python3 run_import.py --dry-run-only   # только dry-run, без записи на сайт
    python3 run_import.py --supplier artkera --confirm   # ручное подтверждение импорта

Конфиг: config.yaml рядом со скриптом (url, token, пороги).
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
import time
import urllib.request
from datetime import datetime
from pathlib import Path

import yaml

IMPORT_DIR = Path(__file__).resolve().parent
INBOX = IMPORT_DIR / "inbox"
PROCESSED = IMPORT_DIR / "processed"
QUARANTINE = IMPORT_DIR / "quarantine"
REPORTS = IMPORT_DIR / "reports"
LOCK_FILE = IMPORT_DIR / ".lock"

sys.path.insert(0, str(IMPORT_DIR))
from convert import convert_supplier  # noqa: E402


def load_config() -> dict:
    return yaml.safe_load((IMPORT_DIR / "config.yaml").read_text(encoding="utf-8"))


def post_batch(config: dict, products: list, dry_run: bool, with_photos: bool) -> dict:
    payload = json.dumps(
        {"dry_run": dry_run, "with_photos": with_photos, "products": products},
        ensure_ascii=False,
    ).encode()
    req = urllib.request.Request(
        config["url"].rstrip("/") + "/local/tools/import/receive.php",
        data=payload,
        method="POST",
        headers={"X-Import-Token": config["token"], "Content-Type": "application/json"},
    )
    last_error = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=280) as resp:
                return json.loads(resp.read())
        except Exception as e:  # noqa: BLE001
            last_error = e
            time.sleep(5)
    raise RuntimeError(f"endpoint недоступен после 3 попыток: {last_error}")


def send_all(config: dict, products: list, dry_run: bool, with_photos: bool, log: list) -> dict:
    batch_size = int(config.get("batch_size", 100))
    total = {"created": 0, "updated": 0, "skipped": 0, "errors": []}
    for i in range(0, len(products), batch_size):
        r = post_batch(config, products[i:i + batch_size], dry_run, with_photos)
        total["created"] += r.get("created", 0)
        total["updated"] += r.get("updated", 0)
        total["skipped"] += r.get("skipped", 0)
        total["errors"].extend(r.get("errors", []))
        log.append(f"партия {i // batch_size + 1}: +{r.get('created', 0)}/~{r.get('updated', 0)} err={len(r.get('errors', []))}")
        time.sleep(1)
    return total


def quarantine_files(supplier: str, files: list, reason: str, report: dict) -> None:
    qdir = QUARANTINE / supplier
    qdir.mkdir(parents=True, exist_ok=True)
    for f in files:
        src = Path(f)
        if src.exists():
            shutil.move(str(src), str(qdir / src.name))
    (qdir / "REASON.txt").write_text(
        f"{datetime.now().isoformat()}\n{reason}\n\n{json.dumps(report, ensure_ascii=False, indent=2)[:5000]}",
        encoding="utf-8",
    )


def archive_files(supplier: str, files: list) -> None:
    pdir = PROCESSED / supplier
    pdir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M")
    for f in files:
        src = Path(f)
        if src.exists():
            shutil.move(str(src), str(pdir / f"{stamp}_{src.name}"))


def process_supplier(supplier: str, config: dict, dry_run_only: bool, confirm: bool = False) -> dict | None:
    inbox_dir = INBOX / supplier
    if not inbox_dir.is_dir():
        return None
    files = [p for p in inbox_dir.iterdir() if p.suffix.lower() in (".xls", ".xlsx")]
    if not files:
        return None

    log: list[str] = [f"файлов в inbox: {len(files)}"]
    result: dict = {"supplier": supplier, "started_at": datetime.now().isoformat(), "log": log}

    sup_conf = config.get("suppliers", {}).get(supplier, {})
    max_errors = int(sup_conf.get("max_convert_errors", 100))
    max_create = int(sup_conf.get("max_create_auto", 500))
    with_photos = bool(sup_conf.get("with_photos", True))
    auto_confirm = bool(sup_conf.get("auto_confirm", False))

    # 1. Конвертация
    try:
        conv = convert_supplier(supplier, files_dir=str(inbox_dir), out_dir=str(IMPORT_DIR / "data" / "normalized"))
    except Exception as e:  # noqa: BLE001
        result["status"] = "quarantine"
        result["reason"] = f"ошибка конвертации: {e}"
        quarantine_files(supplier, files, result["reason"], result)
        return result

    log.append(f"товаров: {conv['total']}, ошибок конвертации: {len(conv['errors'])}")
    result["convert_errors"] = len(conv["errors"])
    result["unknown_categories"] = conv["unknown_categories"]

    # 2. Валидация
    if conv["total"] == 0 or len(conv["errors"]) > max_errors:
        result["status"] = "quarantine"
        result["reason"] = f"валидация: товаров {conv['total']}, ошибок {len(conv['errors'])} (лимит {max_errors})"
        quarantine_files(supplier, files, result["reason"], {"errors": conv["errors"][:50]})
        return result

    # 3. Dry-run на сайте
    dry = send_all(config, conv["products"], dry_run=True, with_photos=False, log=log)
    result["dry_run"] = {k: v for k, v in dry.items() if k != "errors"}
    result["dry_run"]["errors_count"] = len(dry["errors"])
    log.append(f"dry-run: create={dry['created']} update={dry['updated']} err={len(dry['errors'])}")

    if dry["errors"]:
        result["status"] = "quarantine"
        result["reason"] = f"dry-run вернул {len(dry['errors'])} ошибок"
        quarantine_files(supplier, files, result["reason"], {"errors": dry["errors"][:50]})
        return result

    if dry["created"] > max_create:
        result["status"] = "quarantine"
        result["reason"] = f"dry-run: создаётся {dry['created']} товаров (> лимита {max_create}) — нужен ручной запуск"
        quarantine_files(supplier, files, result["reason"], result)
        return result

    if dry_run_only or (not auto_confirm and not confirm):
        result["status"] = "awaiting_confirm" if not dry_run_only else "dry_run_only"
        result["reason"] = "импорт не выполнен: " + (
            "флаг --dry-run-only" if dry_run_only
            else "auto_confirm=false (запустите с --confirm)"
        )
        # файлы остаются в inbox до ручного подтверждения/запуска
        return result

    # 4. Боевой импорт
    real = send_all(config, conv["products"], dry_run=False, with_photos=with_photos, log=log)
    result["import"] = {k: v for k, v in real.items() if k != "errors"}
    result["import"]["errors_count"] = len(real["errors"])
    result["import_errors"] = real["errors"][:50]
    result["status"] = "imported" if not real["errors"] else "imported_with_errors"

    archive_files(supplier, files)
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--supplier", default=None)
    ap.add_argument("--dry-run-only", action="store_true")
    ap.add_argument("--confirm", action="store_true", help="выполнить импорт даже при auto_confirm=false")
    args = ap.parse_args()

    # lock от параллельных запусков cron
    if LOCK_FILE.exists() and time.time() - LOCK_FILE.stat().st_mtime < 3600 * 3:
        print("уже выполняется (lock)")
        sys.exit(0)
    LOCK_FILE.write_text(str(datetime.now()))

    try:
        config = load_config()
        suppliers = [args.supplier] if args.supplier else sorted(
            p.name for p in INBOX.iterdir() if p.is_dir()
        )
        REPORTS.mkdir(parents=True, exist_ok=True)
        ran = 0
        for supplier in suppliers:
            result = process_supplier(supplier, config, args.dry_run_only, confirm=args.confirm)
            if result is None:
                continue
            ran += 1
            result["finished_at"] = datetime.now().isoformat()
            stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
            report_path = REPORTS / f"{stamp}_{supplier}.json"
            report_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"[{supplier}] {result.get('status')} — {result.get('reason', 'ok')} → {report_path.name}")
        if ran == 0:
            print("inbox пуст — нечего делать")
    finally:
        LOCK_FILE.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
